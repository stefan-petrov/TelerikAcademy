-- phpMyAdmin SQL Dump
-- version 4.0.4.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Oct 09, 2013 at 10:30 AM
-- Server version: 5.5.32
-- PHP Version: 5.4.19

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `homework3`
--
CREATE DATABASE IF NOT EXISTS `homework3` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `homework3`;

-- --------------------------------------------------------

--
-- Table structure for table `messages`
--

CREATE TABLE IF NOT EXISTS `messages` (
  `msg_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(25) NOT NULL,
  `msg_title` varchar(50) NOT NULL,
  `msg_data` varchar(250) NOT NULL,
  `category_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  PRIMARY KEY (`msg_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=12 ;

--
-- Dumping data for table `messages`
--

INSERT INTO `messages` (`msg_id`, `user_name`, `msg_title`, `msg_data`, `category_id`, `date`) VALUES
(3, 'steff', 'ada', 'asdsa5', 8, '2013-10-08 21:14:16'),
(2, 'steff', 'sdfsdfs', 'dsffds6', 5, '2013-10-08 21:13:59'),
(4, 'steff', 'fsdf', 'sdfsd5', 4, '2013-10-08 21:19:04'),
(5, 'steff', 'asds', 'sdsd4', 7, '2013-10-08 21:23:39'),
(7, 'steff', 'dsadas', 'asdasda7', 1, '2013-10-08 22:38:39'),
(8, 'steff', 'asdasdas', 'asdasdasdaa11', 1, '2013-10-08 22:38:44'),
(9, 'admin', 'test', 'test4', 1, '2013-10-08 23:09:56'),
(10, 'steff', 'dfs', 'sdfsdfds8', 1, '2013-10-08 23:22:47'),
(11, 'sdfsdf', 'дсасасд', 'адасдас7', 1, '2013-10-09 11:10:17');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `user_id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(25) NOT NULL,
  `password` varchar(15) NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`user_id`, `user_name`, `password`) VALUES
(1, 'asdasd', 'asdasd'),
(2, 'asdas', 'dfsdfsd'),
(3, 'asdas', 'dfsdfsd'),
(4, 'test', 'test'),
(5, 'test', 'test'),
(6, 'test1', 'test'),
(7, 'gdfgd', 'dfgdfd'),
(8, 'stef', '2134'),
(9, 'steff', '12345'),
(10, 'test4', '12345'),
(11, 'test5', '12345'),
(12, 'admin', 'admin'),
(13, 'sdfsdf', 'sdfsdf');

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
